import logging
from pyspark.sql import SparkSession
from src.util import load_config_from_string
from pyspark.sql.functions import col
from pyspark.sql.types import StringType
from src import cast
from src import field

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)


def transform_to_access(spark: SparkSession):
    try:
        logger.info("Loading Spark configuration.")
        sparkConfig = load_config_from_string(spark.conf.get(
            "spark.cdl.configurationSource"))["sparkConfig"]
        source = spark.conf.get("spark.cdl.source")
        stream = spark.conf.get("spark.cdl.stream").replace("_", "")
        proprietor = spark.conf.get("spark.cdl.proprietor")
        current_date = spark.conf.get("spark.cdl.timestamp")
        catalog = sparkConfig["catalog"]
        schema = sparkConfig["schema"]
        ing_date = current_date[0:8]
        table_name = sparkConfig["table_name"]
        Source_bucket = sparkConfig["sourcePath"]
        target_bucket = sparkConfig["targetPath"]
        cast_dict = getattr(cast, f"{stream}_cast")
        fields = getattr(field, f"{stream}_fields")

        logger.info(
            f"Stream: {stream}, Current Date: {current_date}, Ingestion Date: {ing_date}")

        df = spark.read.option("header", "true").parquet(Source_bucket)
        df = df.withColumn("ingestion_date", col(
            "ingestion_date").cast(StringType()))

        for column, data_type in cast_dict.items():
            df = df.withColumn(column, col(column).cast(data_type))

        logger.info(f"Data read successfully from {Source_bucket}")

        logger.info(f"Writing data to table: {table_name}")

        spark.sql(f"""CREATE TABLE IF NOT EXISTS {catalog}.{schema}.{table_name} ({fields}) \
                   USING iceberg PARTITIONED BY (ingestion_date) \
                    LOCATION '{target_bucket}/{table_name}' """)

        df.sort("ingestion_date") \
            .write.format("iceberg").mode('overwrite') \
            .partitionBy("ingestion_date") \
            .option("partitionOverwriteMode", "dynamic") \
            .option("maxRecordsPerFile", 600000) \
            .saveAsTable(f"{catalog}.{schema}.{table_name}")

        logger.info(f"Data successfully written to {table_name}")

    except Exception as e:
        logger.error(f"Error occurred during processing: {e}")
        raise


def curated_to_access(spark: SparkSession):
    transform_to_access(spark)

from pyspark.sql.types import StringType
import logging
import traceback
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit
from src.util import load_config_from_string


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)


def transform_to_curated(spark: SparkSession):
    try:
        logger.info("Loading Spark configuration.")
        sparkConfig = load_config_from_string(spark.conf.get(
            "spark.cdl.configurationSource"))["sparkConfig"]
        source = spark.conf.get("spark.cdl.source")
        stream = spark.conf.get("spark.cdl.stream")
        proprietor = spark.conf.get("spark.cdl.proprietor")
        current_date = spark.conf.get("spark.cdl.timestamp")
        ing_date = current_date[0:8]
        url = sparkConfig["url"]
        username = sparkConfig["username"]
        password = sparkConfig["password"]
        query = sparkConfig["dbtable"]
        target_bucket = f"s3a://data-{proprietor}-{source}-{stream}-curated/data/"
        logger.info(f"Reading data for stream {stream} from the source.")

        df = spark.read \
            .format("jdbc") \
            .option("url", f"{url};trustServerCertificate=true") \
            .option("dbtable", query) \
            .option("user", username) \
            .option("password", password) \
            .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
            .load()
        logger.info(
            f"Data read successfully for {stream} from the source {source}.")

        df = df.withColumn("cdl_batch_id", lit(f"swe_{source}_{stream}_{current_date}").cast(StringType())) \
               .withColumn("ingestion_date", lit(ing_date).cast(StringType()))

        logger.info("Casting completed for columns based on cast_dict.")
        logger.info(f"Writing data to {target_bucket}.")

        df.write \
          .partitionBy("ingestion_date") \
          .option("header", "true")  \
          .option("maxRecordsPerFile", 600000) \
          .mode('overwrite') \
          .parquet(target_bucket)

        logger.info(f"Data written to {target_bucket} successfully.")

    except Exception as e:
        logger.error(
            f"Error occurred while processing data for stream {stream}: {e}")
        logger.error(traceback.format_exc())
        raise


def source_to_curated(spark: SparkSession):
    transform_to_curated(spark)

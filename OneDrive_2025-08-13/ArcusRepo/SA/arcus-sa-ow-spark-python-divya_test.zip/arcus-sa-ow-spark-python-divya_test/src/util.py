from datetime import datetime
import json


def load_config_from_string(json_content: str) -> dict:
    """
    Parses a JSON string.
    :param json_content: JSON document
    :return: JSON as dict
    """
    return json.loads(json_content)

# arcus-sa-ow-spark-python
## General Information

| Job Details | Comments |
| ------ | ------ |
| Tenant | Network |
| source 2 curated | Pulls Data from JDBC and load it to the curated layer |
| Curated 2 access | read the data from curated layer and load it to the access layer |
| Alert & Notification's enabled | True |

## Source2Curated layer

This job reads data from the source database, adds technical columns, and writes it to the Curated layer in the Curated bucket.
The data is stored in Parquet format, partitioned by ingestion date.

## Source2Curated layer

This job reads data from the Curated layer, adds additional technical columns, and writes it to the Access layer in the Access bucket.
The data is stored in Iceberg format, partitioned by business date.

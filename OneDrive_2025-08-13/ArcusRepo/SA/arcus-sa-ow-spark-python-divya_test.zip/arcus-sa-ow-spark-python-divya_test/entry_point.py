import logging
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import col, lit
from src.util import load_config_from_string
import src.source_to_curated as s2c
import src.curated_to_access as cta


logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)


def execute(spark: SparkSession):
    """Executes a job based on the Spark configuration."""
    try:
        config = spark.conf.get("spark.cdl.configurationSource")
        if not config:
            raise ValueError(
                "No 'spark.cdl.configurationSource' found in Spark configuration."
            )
        job_config = load_config_from_string(config)
        job = job_config.get("job")

        logger.info(f"Starting job: {job}")

        if job == "source-to-curated":
            logger.info("Executing 'source-to-curated' job.")
            s2c.source_to_curated(spark)
        elif job == "curated-to-access":
            logger.info("Executing 'curated-to-access' job.")
            cta.curated_to_access(spark)
        else:
            raise ValueError(
                f"Unknown job: {job}. Supports 'source-to-curated', "
                "'curated-to-access'"
            )

    except Exception as e:
        logger.error(f"Failed to execute job: {str(e)}", exc_info=True)
        raise


def business_logic(spark: SparkSession, df: DataFrame) -> DataFrame:
    """Filters a DataFrame based on a timestamp from Spark configuration."""
    timestamp = spark.conf.get("spark.cdl.timestamp")
    return df.filter(col("_timestamp_") == lit(timestamp))

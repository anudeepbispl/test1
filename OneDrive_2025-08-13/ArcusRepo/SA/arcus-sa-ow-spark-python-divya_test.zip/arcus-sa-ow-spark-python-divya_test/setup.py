from setuptools import find_packages, setup

setup(
    name="arcus_sa_ow_app",
    version="1.0.0",
    description="TODO: Replace with short description of this python app",
    maintainer="sa",
    url="https://github.com/telia-company/arcus-sa-ow-spark-python",
    license="Telia Company",
    platforms=["ARCUS"],
    packages=find_packages(exclude=["*tests*"]),
    py_modules=["entry_point"]
)

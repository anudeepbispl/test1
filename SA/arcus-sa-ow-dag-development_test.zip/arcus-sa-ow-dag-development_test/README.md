# arcus-sa-ow-spark-python
## General Information

| Job Details | Comments |
| ------ | ------ |
| Tenant | Network |
| Dag Name | "swe_${project.artifactId}_${project.version}"; |
| Frequency | 0 2 * * * (Run Once a Day at 2:00 AM UTC) |
| Alert & Notification's enabled | True |


Curated partitions: ingestion_date
Access Partition: business_date


# Airflow for Workflow data

See confluence: [https://itwiki.atlassian.teliacompany.net/display/DAP/Current+Architecture] # As of now refering the old one 

Job Frequency: Daily


## AF Variables

The json values in `af_variables` folder will probably be outdated, by definition.

But if you modify the json structure, make sure to

- update the json here
- update the unit tests

## Failure handling

In case of failure all tasks are set to auto retry `two times`.  
If all retries fail, task is marked as `Failed` and marked `red` in the Airflow UI.  
To perform task restart, clear the failed task including downstream tasks:

1. Open grid or graph view of the DAG
2. Click on the failed task (red square)
3. Click the `Clear task` button
4. Make sure `Donwstream` and `Recursive` options are included
5. Click `Clear` and the tasks will re-run

Contact Network squad for clarifications and details if needed.

'''
# General Information

DAG for ingesting One Workflow data.

* Dag name: arcus-ra-ow-<PROJECT_VERSION>
* Job Frequency: Daily
* Airflow UI URLs:
  * Prod: https://sa.af.prod.arcus.teliacompany.net/home
  * Test: https://sa.af.test.arcus.teliacompany.net/home
  * Dev:  https://sa.af.dev.arcus.teliacompany.net/home

## Failure handling

In case of failure all tasks are set to auto retry `three times`.  
If all retries fail, task is marked as `Failed` and marked `red` in the Airflow UI.  
To perform task restart, clear the failed task including downstream tasks:

1. Open grid or graph view of the DAG
2. Click on the failed task (red square)
3. Click the `Clear task` button
4. Make sure `Donwstream` and `Recursive` options are included
5. Click `Clear` and the tasks will re-run
'''

from datetime import datetime
from datetime import timedelta
from common.config import DAG_OWNER, PROJECT_ARTIFACT_ID_UNDERSCORE
from common.utils import compute_year_4digit_pattern, compute_month_noleadingzero_pattern
from common.utils import compute_day_noleadingzero_pattern
from common.tasks import jdbc_to_base, wait_for_files, retention
from common.tasks import curated_to_access, SOURCE, SOURCE_ACCESS
from common.config import PROJECT_ARTIFACT_ID, PROJECT_VERSION
from common.stream import get_enabled_incremental_streams, get_enabled_full_streams
from common.streams import full_ingestion_streams, incremental_ingestion_streams
from common.gx_enum import Layer
from common.gx_config import Configuration
from arcus.operators.spark.python import get_spark_submit_operator
from arcus.python_application_artifact import PythonApplicationArtifact
from airflow.models import DAG, Variable


start_date = datetime(2025, 3, 22)
DAG_NAME = f"{PROJECT_ARTIFACT_ID}-{PROJECT_VERSION}"
conf = Variable.get(PROJECT_ARTIFACT_ID_UNDERSCORE, deserialize_json=True)


def create_validation_task(configuration: Configuration, layer: Layer):
    return get_spark_submit_operator(
        artifact=PythonApplicationArtifact(
            package_name='arcus_great_expectations_pyspark',
            version=Variable.get(
                'GREAT_EXPECTATIONS_APP_VERSION', default_var='1.6.0-py3.10'),
            squad='na'
        ),
        archives='s3a://artifacts/na/'
                 f'gx-conda-env-{Variable.get("GREAT_EXPECTATIONS_CONDA_ENV_VERSION", default_var="0_18_21")}'
                 '.tar.gz#environment',
        configuration=configuration.get_gx_configuration(layer),
        task_id=configuration.get_task_id(
            f'gx-{layer.value}-{configuration.gx.get(layer).get("level").name}'
        ),
        executor_cores=4,
        executor_memory='2g',
        num_executors=2,
        verbose=True,
        driver_memory='8g',
        email_on_failure=False,
        env_vars={
            "PYSPARK_PYTHON": "./environment/bin/python"
        },
    )


default_args = {
    'owner': DAG_OWNER,
    'depends_on_past': False,
    'start_date': start_date,
    'end_date': None,
    'email': None,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 3,
    'execution_timeout': timedelta(hours=conf['execution_timeout_hours']),
    'retry_delay': timedelta(minutes=3)
}

with DAG(
    dag_id=DAG_NAME,
    start_date=start_date,
    end_date=None,
    schedule_interval="0 2 * * *",
    max_active_runs=1,
    concurrency=10,
    orientation='LR',
    default_args={
        'owner': DAG_OWNER,
        'depends_on_past': False,
        'start_date': start_date,
        'end_date': None,
        'email': None,
        'email_on_failure': False,
        'email_on_retry': False,
        'retries': 3,
        'retry_delay': timedelta(minutes=3)
    },
    user_defined_macros={
        "to_year_4digit_pattern": compute_year_4digit_pattern,
        "to_month_noleadingzero_pattern": compute_month_noleadingzero_pattern,
        "to_day_noleadingzero_pattern": compute_day_noleadingzero_pattern
    }
) as dag:
    enabled_incremental_streams = get_enabled_incremental_streams(
        incremental_ingestion_streams, conf)
    enabled_full_streams = get_enabled_full_streams(
        full_ingestion_streams, conf)

    for stream in enabled_incremental_streams:
        streams = stream.name
        jdbc_to_base_task = jdbc_to_base(dag, stream)
        wait_for_a_stream = wait_for_files(stream)
        gx_validation_task_min = create_validation_task(
            Configuration(SOURCE, streams, Configuration.get_mapping().get(
                streams)), Layer.CURATED
        )
        curated_to_access_task = curated_to_access(dag, stream)
        gx_validation_task_ext = create_validation_task(
            Configuration(SOURCE_ACCESS, streams, Configuration.get_mapping().get(
                streams)), Layer.ACCESS
        )
        retention_task = retention(stream)

        jdbc_to_base_task >> wait_for_a_stream >> gx_validation_task_min >> curated_to_access_task >> gx_validation_task_ext >> retention_task

    for stream in enabled_full_streams:
        streams = stream.name
        jdbc_to_base_task = jdbc_to_base(dag, stream)
        wait_for_a_stream = wait_for_files(stream)
        gx_validation_task_min = create_validation_task(
            Configuration(SOURCE, streams, Configuration.get_mapping().get(
                streams)), Layer.CURATED
        )
        curated_to_access_task = curated_to_access(dag, stream)
        gx_validation_task_ext = create_validation_task(
            Configuration(SOURCE_ACCESS, streams, Configuration.get_mapping().get(
                streams)), Layer.ACCESS
        )
        retention_task = retention(stream)

        jdbc_to_base_task >> wait_for_a_stream >> gx_validation_task_min >> curated_to_access_task >> gx_validation_task_ext >> retention_task

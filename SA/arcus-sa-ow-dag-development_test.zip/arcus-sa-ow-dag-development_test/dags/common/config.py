''' Common constants and configurations. '''


def project_version() -> str:
    from cdl.env import Env
    if not Env.is_dev_env():
        return "${project.version}"
    else:
        return "1.0.0-SNAPSHOT"


DAG_OWNER = "sa"
PROJECT_ARTIFACT_ID = "arcus-sa-ow"
PROJECT_ARTIFACT_ID_UNDERSCORE = "arcus_sa_ow"
PROJECT_VERSION = project_version()

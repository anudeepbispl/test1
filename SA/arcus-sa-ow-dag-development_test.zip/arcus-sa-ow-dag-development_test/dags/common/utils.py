def compute_year_4digit_pattern(execution_date):
    return execution_date.strftime("%Y")


def compute_month_noleadingzero_pattern(execution_date):
    return execution_date.strftime("%-m")


def compute_day_noleadingzero_pattern(execution_date):
    return execution_date.strftime("%-d")

from typing import Dict
from common.streams import IncrementalStream
from arcus.env import get_squad
from arcus.env import get_access_bucket_name
from arcus.python_application_artifact import PythonApplicationArtifact
from arcus.operators.spark.python import get_spark_submit_operator
from arcus.stream_configuration import TimestampStreamConfiguration
from arcus.operators.java.retention import get_retention_operator
from arcus.env import get_curated_bucket_name
from airflow.models import DAG, Variable, Connection
from airflow.providers.amazon.aws.sensors.s3 import S3KeySensor


af_variable = Variable.get('arcus_sa_ow', deserialize_json=True)
JAR_FILE = af_variable["JAR_FILE"]
ARTIFACT = af_variable["ARTIFACT"]
VERSION = af_variable["VERSION"]
SOURCE = "ow"
SOURCE_ACCESS = "ow1016"
PROPRIETOR = get_squad()
current_date = "{{ ds_nodash }}"


PG_CONNECTION = Connection.get_connection_from_secrets("jdbc_ow_source")
PG_USERNAME = PG_CONNECTION.login
PG_PASSWORD = PG_CONNECTION.password
PG_URL = PG_CONNECTION.host


def jdbc_to_base_path(stream: IncrementalStream) -> str:
    return f"s3a://data-{PROPRIETOR}-{SOURCE}-{stream.name}-curated/data/"


def access_target_path(stream: IncrementalStream) -> str:
    return f"s3a://data-{PROPRIETOR}-{SOURCE_ACCESS}-{stream.name}-access/"


def table_name(stream: IncrementalStream) -> str:
    return f"t_{PROPRIETOR}_{SOURCE_ACCESS}_{stream.name}"


def get_spark_default(bucket_name: str) -> Dict:
    return {
        "spark.driver.cores": 2,
        "spark.driver.memory": "6g",
        "spark.executor.instances": 6,
        "spark.executor.cores": 2,
        "spark.executor.memory": "8g",
        "spark.dynamicAllocation.enabled": True,
        "spark.dynamicAllocation.initialExecutors": "1",
        "spark.dynamicAllocation.minExecutors": 2,
        "spark.dynamicAllocation.maxExecutors": 10,
        "spark.sql.inMemoryColumnarStorage.compressed": True,
        "spark.sql.legacy.timeParserPolicy": "LEGACY",
        "spark.jars": (
            "s3a://artifacts/dgov/acryl-spark-lineage.jar,"
            "s3a://artifacts/ra/iceberg-spark-runtime-3.3_2.12-1.6.1.jar"
        ),
        "spark.sql.extensions": "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions",
        "spark.sql.catalog.iceberg": "org.apache.iceberg.spark.SparkCatalog",
        "spark.sql.catalog.iceberg.type": "hive",
        "spark.sql.catalog.iceberg.warehouse": f"s3a://{bucket_name}/"
    }


def wait_for_files(stream: IncrementalStream) -> str:
    return S3KeySensor(
        bucket_name=get_curated_bucket_name(SOURCE, stream.name),
        bucket_key=f"data/ingestion_date={current_date}/*",
        wildcard_match=True,
        aws_conn_id="minio_data",
        mode="reschedule",
        poke_interval=60,
        timeout=60 * 60,
        task_id=f"wait-for-key-in-{stream.name}",
    )


def retention(stream: IncrementalStream) -> str:
    return get_retention_operator(
        configuration=TimestampStreamConfiguration(
            SOURCE,
            stream.name,
            cdl_configuration_source={
                "location": {
                    "bucket": get_curated_bucket_name(SOURCE, stream.name),
                    "partitionPattern": "'ingestion_date='yyyyMMdd",
                },
                "retentionPeriod": "P6M",
            },
        )
    )


def jdbc_to_base(dag: DAG, stream: IncrementalStream) -> get_spark_submit_operator:
    conf = get_spark_default(get_access_bucket_name(SOURCE, stream.name))
    stream_configuration = TimestampStreamConfiguration(
        SOURCE,
        stream.name,
        cdl_configuration_source={
            "job": "source-to-curated",
            "sparkConfig": {
                "spark.jars": JAR_FILE,
                "spark.hadoop.fs.s3a.connection.ssl.enabled": "true",
                "spark.hadoop.fs.s3a.path.style.access": "true",
                "sourcePath": jdbc_to_base_path(stream),
                "dbtable": stream.query(),
                "url": PG_URL,
                "username": PG_USERNAME,
                "password": PG_PASSWORD
            }
        }
    )
    return get_spark_submit_operator(
        task_id=f'{PROPRIETOR}-{SOURCE}-{stream.name}-source-to-curated',
        conf=conf,
        artifact=PythonApplicationArtifact(f"{ARTIFACT}", f"{VERSION}-py3.9"),
        jars=JAR_FILE,
        configuration=stream_configuration
    )


def curated_to_access(dag: DAG, stream: IncrementalStream) -> get_spark_submit_operator:
    conf = get_spark_default(get_access_bucket_name(SOURCE, stream.name))
    stream_configuration = TimestampStreamConfiguration(
        SOURCE,
        stream.name,
        cdl_configuration_source={
            "job": "curated-to-access",
            "sparkConfig": {
                "sourcePath": jdbc_to_base_path(stream),
                "targetPath": access_target_path(stream),
                "table_name": table_name(stream),
                "catalog": "iceberg",
                "schema": "iceberg",
                "spark.cdl.date": "{{ ds }}"
            }
        }
    )
    return get_spark_submit_operator(
        task_id=f'{PROPRIETOR}-{SOURCE}-{stream.name}-curated-to-access',
        conf=conf,
        artifact=PythonApplicationArtifact(f"{ARTIFACT}", f"{VERSION}-py3.9"),
        jars=JAR_FILE,
        configuration=stream_configuration
    )

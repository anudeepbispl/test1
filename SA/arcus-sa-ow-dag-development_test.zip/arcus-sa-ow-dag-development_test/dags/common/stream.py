from typing import List, Dict, Callable, Optional
from typing import Any
from dataclasses import dataclass, field
from airflow.models import Variable
from common.config import PROJECT_ARTIFACT_ID_UNDERSCORE


CLOSED_METHOD = 'CLOSED'
OPEN_END_METHOD = 'OPEN_END'
WINDOW_METHOD_FLAGS = {CLOSED_METHOD, OPEN_END_METHOD}

dag_conf = Variable.get(PROJECT_ARTIFACT_ID_UNDERSCORE, deserialize_json=True)


@dataclass
class IngestWindow:
    duration_hours: int
    method: str

    def __post_init__(self):
        assert self.method in WINDOW_METHOD_FLAGS, f"Invalid method: {self.method}"
        if self.method == CLOSED_METHOD:
            assert self.duration_hours > 0, "For 'CLOSED' method, 'duration_hours' must be greater than 0"


ingest_window = IngestWindow(
    duration_hours=dag_conf['ingest_window']['duration_hours'],
    method=dag_conf['ingest_window']['method']
) if dag_conf['ingest_window'] else None


@dataclass
class Stream:
    name: str
    source: str
    columns: List[str]
    column_transforms: Dict[str, Callable[[str], str]]

    @property
    def columns_sql(self) -> str:
        return ', '.join([self.column_transforms.get(c, noop)(c) for c in self.columns])


def sql_keyword_escape(s: str) -> str:
    return f'[{s}]'


def sql_as(source, target):
    return f'{source} AS {target}'


def noop(x: Any) -> Any:
    return x


@dataclass
class FullStream(Stream):
    ''' Full Ingestion Stream, behaves similarly to IncrementalStream '''
    columns_to_censor: List[str] = field(default_factory=list)

    ingest_window: Optional[IngestWindow] = None

    def query(self) -> str:
        return f'( SELECT {self.columns_sql} FROM {self.source} ) AS {self.name}'

    def get_columns(self) -> str:
        columns_to_select = [
            col for col in self.columns if col not in self.columns_to_censor]
        transformed_columns = []
        for col in columns_to_select:
            if col in self.column_transforms:
                transformed_column = self.column_transforms[col](col)
                transformed_columns.append(transformed_column)
            else:
                transformed_columns.append(col)
        return ", ".join(transformed_columns)


@dataclass
class IncrementalStream(Stream):
    record_key_field: str
    precombine_field: str
    ingest_window: Optional[IngestWindow] = field(
        default_factory=lambda: ingest_window)
    columns_to_censor: List[str] = field(default_factory=list)

    def query(self) -> str:
        columns = self.get_columns()
        if self.ingest_window:
            window_methods = {
                'CLOSED': self.ingest_window_sql_closed,
                'OPEN_END': self.ingest_window_sql_open_end,
            }
            window_method = window_methods.get(self.ingest_window.method)
            if window_method:
                where_sql = window_method(self.ingest_window.duration_hours)
                return f"(SELECT {columns} FROM {self.source} WHERE {where_sql}) AS {self.name}"
            else:
                return self.full_query(columns)
        else:
            return self.full_query(columns)

    def full_query(self, columns) -> str:
        ''' SQL for full reingest '''
        return f"(SELECT {columns} FROM {self.source}) AS {self.name}"

    def ingest_window_sql_open_end(self, duration_hours) -> str:
        ''' Given only a start timestamp for an open-ended window '''
        DS_NODASH = '{{ ds_nodash }}'
        return ' '.join([
            f"CONVERT(datetime, DATEADD(second, {self.precombine_field}, '19700101'))",
            ">",
            f"CONVERT(datetime, DATEADD(hour, -{duration_hours}, '{DS_NODASH}'))",
        ])

    def ingest_window_sql_closed(self, duration_hours) -> str:
        ''' Given both a start and end timestamp for a closed window '''
        DS_NODASH = '{{ ds_nodash }}'
        return ' '.join([
            f"CONVERT(datetime, DATEADD(second, {self.precombine_field}, '19700101'))",
            ">",
            f"CONVERT(datetime, DATEADD(hour, -{duration_hours}, '{DS_NODASH}'))",
            "AND",
            f"CONVERT(datetime, DATEADD(second, {self.precombine_field}, '19700101'))",
            "<=",
            f"CONVERT(datetime, '{DS_NODASH}')",
        ])

    def get_columns(self) -> str:
        columns_to_select = [
            col for col in self.columns if col not in self.columns_to_censor]
        transformed_columns = []
        for col in columns_to_select:
            if col in self.column_transforms:
                transformed_column = self.column_transforms[col](col)
                transformed_columns.append(transformed_column)
            else:
                transformed_columns.append(col)
        return ", ".join(transformed_columns)


def get_enabled_incremental_streams(streams: List[IncrementalStream], conf: Dict) -> List[IncrementalStream]:
    ''' It is possible to override the streams by providing an override in Variable:

        "overrides": {
            "enabled_incremental_streams": [
                {
                    "name": str,
                    "ingest_window": {"duration_hours": int, "method": str} | null
                },
                ...
            ]
        }

    If overrides are provided, we select those incremental streams only and set their ingest_window.
    Setting ingest_window to null creates a full query without any time window.

    NOTE overrides should only be set in special cases, typically for initial ingestion
    of a new stream where we set the window to some large value, ingest, and remove the override.
    '''
    overrides = {
        s["name"]: s["ingest_window"] for s in conf.get('overrides', {}).get("enabled_incremental_streams", [])
    }
    if overrides:
        override_streams = [s for s in streams if s.name in overrides.keys()]
        assert len(override_streams) == len(overrides.keys())
        for s in override_streams:
            override_window = overrides[s.name]
            s.ingest_window = IngestWindow(
                duration_hours=override_window["duration_hours"],
                method=override_window["method"]
            ) if override_window else None
        return override_streams
    else:
        return streams


def get_enabled_full_streams(streams: List[FullStream], conf: Dict) -> List[FullStream]:
    ''' It is possible to override the streams by providing an override in Variable:

        "overrides": {
            "enabled_full_streams": [str, ...]  # list of stream names
        }

    This method is for full streams which don't have an ingest window.
    If overrides are provided, we select those streams only.

    NOTE overrides should only be set in special cases, typically for initial ingestion.
    '''
    overrides = conf.get('overrides', {}).get("enabled_full_streams", [])
    return overrides if overrides else streams

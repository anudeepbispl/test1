from enum import Enum


class Layer(str, Enum):
    CURATED = 'curated'
    ACCESS = 'access'


class GXValidationLevel(Enum):
    MIN = 1
    EXT = 2

    @property
    def name(self):
        return super().name.lower()

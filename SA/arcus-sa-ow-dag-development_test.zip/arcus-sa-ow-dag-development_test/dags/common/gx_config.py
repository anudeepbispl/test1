from typing import Dict
import pendulum
from airflow.hooks.base import BaseHook
from arcus import env
from arcus.env import is_prod_env, get_bucket_name, get_squad
from arcus.stream_configuration import StreamConfiguration
from common.gx_enum import GXValidationLevel, Layer
from airflow.models import Variable
start_date = pendulum.datetime(2024, 12, 15, tz='UTC')
squad = get_squad()


class Configuration:
    """
        Represents ow configuration object.
    """

    def __init__(self, source: str,  stream: str, mapping: Dict):
        self.source = source
        self.stream = stream
        self.squad = get_squad()
        self.gx = mapping.get(
            'gx', {}
        )

    def get_task_id(self, task_name: str) -> str:
        return f'{env.get_squad()}-{self.source}-{self.stream}-{task_name}'[:63]


    def get_gx_configuration(self, layer: Layer) -> StreamConfiguration:
        gx_conn = BaseHook.get_connection('GX_DB')
        current_date = "{{ ds_nodash }}"
        if layer == Layer.ACCESS:
            data_paths = f'/t_{self.squad}_{self.source}_{self.stream}/data/ingestion_date={current_date}'
            base_path = f'/t_{self.squad}_{self.source}_{self.stream}/data/'
        else:
            data_paths = f'/data/ingestion_date={current_date}'
            base_path = '/data/'

        return StreamConfiguration(
            self.source, self.stream,
            configuration={
                'spark.cdl.greatExpectationsSuiteName': (
                    f'arcus_{self.squad}_{self.source}_{self.stream}_{layer.value}_'
                    f'{self.gx.get(layer).get("level").name}_'
                    f'quality_{self.gx.get(layer).get("version")}'
                ),
                'spark.cdl.bucket': get_bucket_name(
                    proprietor=self.squad,
                    source=self.source,
                    stream=self.stream,
                    layer=layer.value
                ),
                'spark.cdl.dataPaths': data_paths,
                'spark.cdl.basePath': base_path,
                'spark.cdl.postgres_db_config': (
                    '{'
                    f'"username": "{gx_conn.login}",'
                    f'"password": "{gx_conn.password}",'
                    f'"database": "{gx_conn.schema}"'
                    '}'
                ),
                'spark.cdl.email_config': (
                    '{"enabled": true, '
                    '"from_email_address": "arcus_sa_af_gx_validation@teliacompany.com", '
                    f'"to_email_addresses": "{Variable.get("SA_RECIPIENTS_LIST")}",'
                    '"email_renderer_defaults": {"include_ext_details": true}}'
                ),
                'spark.cdl.run_name': (
                    f'{{{{ macros.ds_format(ds, "%Y-%m-%d", "%Y%m%d") }}}}_'
                    f'{self.gx.get(layer).get("version")}'
                )
            }
        )

    @staticmethod
    def get_spark_configuration():
        dynamic_partition_overwrite = {
            'spark.sql.sources.partitionOverwriteMode':
                'dynamic',
            'spark.sql.parquet.output.committer.class':
                'org.apache.parquet.hadoop.ParquetOutputCommitter',
            'spark.sql.sources.commitProtocolClass':
                'org.apache.spark.sql.execution.datasources.SQLHadoopMapReduceCommitProtocol'
        }

        return {
            'spark.executor.memory': '4g',
            'spark.driver.memory': '8g',
            'spark.dynamicAllocation.enabled': True,
            'spark.dynamicAllocation.initialExecutors': 2,
            'spark.dynamicAllocation.minExecutors': 1,
            'spark.dynamicAllocation.maxExecutors': 12,
            **dynamic_partition_overwrite
        }

    @staticmethod
    def get_mapping() -> Dict:
        return {
            "os3admgroupuserprofi": {
                'gx': {
                    Layer.CURATED: {
                        'level': GXValidationLevel.MIN,
                        'version': '0_1'
                    },
                    Layer.ACCESS: {
                        'level': GXValidationLevel.EXT,
                        'version': '0_1'
                    }
                }
            },
            "os3admuser": {
                'gx': {
                    Layer.CURATED: {
                        'level': GXValidationLevel.MIN,
                        'version': '0_1'
                    },
                    Layer.ACCESS: {
                        'level': GXValidationLevel.EXT,
                        'version': '0_1'
                    }
                }
            },
            "os3cmrequestconsolid": {
                'gx': {
                    Layer.CURATED: {
                        'level': GXValidationLevel.MIN,
                        'version': '0_1'
                    },
                    Layer.ACCESS: {
                        'level': GXValidationLevel.EXT,
                        'version': '0_1'
                    }
                }
            },
            "os3cmriskquestionans": {
                'gx': {
                    Layer.CURATED: {
                        'level': GXValidationLevel.MIN,
                        'version': '0_1'
                    },
                    Layer.ACCESS: {
                        'level': GXValidationLevel.EXT,
                        'version': '0_1'
                    }
                }
            },
            "os3opnmsintegrationi": {
                'gx': {
                    Layer.CURATED: {
                        'level': GXValidationLevel.MIN,
                        'version': '0_1'
                    },
                    Layer.ACCESS: {
                        'level': GXValidationLevel.EXT,
                        'version': '0_1'
                    }
                }
            },
            "os3oprequest": {
                'gx': {
                    Layer.CURATED: {
                        'level': GXValidationLevel.MIN,
                        'version': '0_1'
                    },
                    Layer.ACCESS: {
                        'level': GXValidationLevel.EXT,
                        'version': '0_1'
                    }
                }
            },
            "os3oprequestconsolid": {
                'gx': {
                    Layer.CURATED: {
                        'level': GXValidationLevel.MIN,
                        'version': '0_1'
                    },
                    Layer.ACCESS: {
                        'level': GXValidationLevel.EXT,
                        'version': '0_1'
                    }
                }
            },
            "os3pbknownerror": {
                'gx': {
                    Layer.CURATED: {
                        'level': GXValidationLevel.MIN,
                        'version': '0_1'
                    },
                    Layer.ACCESS: {
                        'level': GXValidationLevel.EXT,
                        'version': '0_1'
                    }
                }
            },
            "os3pbrequest": {
                'gx': {
                    Layer.CURATED: {
                        'level': GXValidationLevel.MIN,
                        'version': '0_1'
                    },
                    Layer.ACCESS: {
                        'level': GXValidationLevel.EXT,
                        'version': '0_1'
                    }
                }
            },
            "os3sidcihistoryconso": {
                'gx': {
                    Layer.CURATED: {
                        'level': GXValidationLevel.MIN,
                        'version': '0_1'
                    },
                    Layer.ACCESS: {
                        'level': GXValidationLevel.EXT,
                        'version': '0_1'
                    }
                }
            },
            "os3sidcihistoryimpac": {
                'gx': {
                    Layer.CURATED: {
                        'level': GXValidationLevel.MIN,
                        'version': '0_1'
                    },
                    Layer.ACCESS: {
                        'level': GXValidationLevel.EXT,
                        'version': '0_1'
                    }
                }
            },
            "os3sidgeolocnameurba": {
                'gx': {
                    Layer.CURATED: {
                        'level': GXValidationLevel.MIN,
                        'version': '0_1'
                    },
                    Layer.ACCESS: {
                        'level': GXValidationLevel.EXT,
                        'version': '0_1'
                    }
                }
            },
            "os3sidimpactdetailco": {
                'gx': {
                    Layer.CURATED: {
                        'level': GXValidationLevel.MIN,
                        'version': '0_1'
                    },
                    Layer.ACCESS: {
                        'level': GXValidationLevel.EXT,
                        'version': '0_1'
                    }
                }
            },
            "os3sysassignmentrule": {
                'gx': {
                    Layer.CURATED: {
                        'level': GXValidationLevel.MIN,
                        'version': '0_1'
                    },
                    Layer.ACCESS: {
                        'level': GXValidationLevel.EXT,
                        'version': '0_1'
                    }
                }
            },
            "os3sysnotificationau": {
                'gx': {
                    Layer.CURATED: {
                        'level': GXValidationLevel.MIN,
                        'version': '0_1'
                    },
                    Layer.ACCESS: {
                        'level': GXValidationLevel.EXT,
                        'version': '0_1'
                    }
                }
            },
            "os3sysrecordrelation": {
                'gx': {
                    Layer.CURATED: {
                        'level': GXValidationLevel.MIN,
                        'version': '0_1'
                    },
                    Layer.ACCESS: {
                        'level': GXValidationLevel.EXT,
                        'version': '0_1'
                    }
                }
            },
            "os3sysstatushistoryc": {
                'gx': {
                    Layer.CURATED: {
                        'level': GXValidationLevel.MIN,
                        'version': '0_1'
                    },
                    Layer.ACCESS: {
                        'level': GXValidationLevel.EXT,
                        'version': '0_1'
                    }
                }
            },
            "os3sysworkflowconsol": {
                'gx': {
                    Layer.CURATED: {
                        'level': GXValidationLevel.MIN,
                        'version': '0_1'
                    },
                    Layer.ACCESS: {
                        'level': GXValidationLevel.EXT,
                        'version': '0_1'
                    }
                }
            },
            "os3worequestconsolid": {
                'gx': {
                    Layer.CURATED: {
                        'level': GXValidationLevel.MIN,
                        'version': '0_1'
                    },
                    Layer.ACCESS: {
                        'level': GXValidationLevel.EXT,
                        'version': '0_1'
                    }
                }
            },
            "os3worequestinterfac": {
                'gx': {
                    Layer.CURATED: {
                        'level': GXValidationLevel.MIN,
                        'version': '0_1'
                    },
                    Layer.ACCESS: {
                        'level': GXValidationLevel.EXT,
                        'version': '0_1'
                    }
                }
            },
            "pdboprequest": {
                'gx': {
                    Layer.CURATED: {
                        'level': GXValidationLevel.MIN,
                        'version': '0_1'
                    },
                    Layer.ACCESS: {
                        'level': GXValidationLevel.EXT,
                        'version': '0_1'
                    }
                }
            },
            "smitsidcommonsidroot": {
                'gx': {
                    Layer.CURATED: {
                        'level': GXValidationLevel.MIN,
                        'version': '0_1'
                    },
                    Layer.ACCESS: {
                        'level': GXValidationLevel.EXT,
                        'version': '0_1'
                    }
                }
            },
            "tsdistdriftinfo": {
                'gx': {
                    Layer.CURATED: {
                        'level': GXValidationLevel.MIN,
                        'version': '0_1'
                    },
                    Layer.ACCESS: {
                        'level': GXValidationLevel.EXT,
                        'version': '0_1'
                    }
                }
            },
            "tsdistdriftinfoconso": {
                'gx': {
                    Layer.CURATED: {
                        'level': GXValidationLevel.MIN,
                        'version': '0_1'
                    },
                    Layer.ACCESS: {
                        'level': GXValidationLevel.EXT,
                        'version': '0_1'
                    }
                }
            },
            "tswob2borderline": {
                'gx': {
                    Layer.CURATED: {
                        'level': GXValidationLevel.MIN,
                        'version': '0_1'
                    },
                    Layer.ACCESS: {
                        'level': GXValidationLevel.EXT,
                        'version': '0_1'
                    }
                }
            },
        }

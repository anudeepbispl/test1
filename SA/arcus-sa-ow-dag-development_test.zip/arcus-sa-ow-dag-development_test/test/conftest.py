import pytest
import json
from pathlib import Path
from airflow.models import DagBag
from airflow.models import Connection


@pytest.fixture
def mock_owad_variable(monkeypatch) -> None:
    with open(f'{Path.cwd()}/test/af_variables/ow.json', 'r') as f:
        res = json.load(f)
        dump = json.dumps(res)
        monkeypatch.setenv('arcus_sa_owad', dump)
        # NOTE monkeypatching the same env with different values to test a different Variable
        # currently doesn't work, DagBag creates a DAG with the first monkeypatched value.
        # TODO figure out how to test Variable with overrides.
    return res


@pytest.fixture
def mock_suqad_env(monkeypatch) -> None:
    """Unittest env is dev."""
    monkeypatch.setenv('CDL_ENV', 'dev')


@pytest.fixture
def mock_jdbc_connection(monkeypatch) -> None:
    conn = Connection(
        conn_type="jdbc",
        login="my_user",
        password="my_password",
        host="mock_host",
    )
    monkeypatch.setenv("AIRFLOW_CONN_JDBC_OW_SOURCE", conn.get_uri())


@pytest.fixture
def mock_gx_connection(monkeypatch) -> None:
    conn = Connection(
        login="my_user",
        password="my_password",
        schema="my_schema",
    )
    monkeypatch.setenv("AIRFLOW_CONN_GX_DB", conn.get_uri())


@pytest.fixture()
def dagbag(
    monkeypatch,
    mock_owad_variable,
    mock_suqad_env,
    mock_jdbc_connection,
    mock_gx_connection
) -> DagBag:
    # Assuming test is run from base directory for project /
    return DagBag(dag_folder=f"{Path.cwd()}/dags/ow.py", include_examples=False)


@pytest.fixture()
def ad_dag_id(mock_owad_variable, mock_suqad_env, mock_jdbc_connection, mock_gx_connection) -> str:
    """For unit tests."""
    from common.config import PROJECT_ARTIFACT_ID, PROJECT_VERSION
    return f"{PROJECT_ARTIFACT_ID}-{PROJECT_VERSION}"

def test_streams_sanity(
    mock_owad_variable,
):
    # Get the Streams defined in our code
    import common.streams as ows
    import common.stream as ow
    full_streams = ows.full_ingestion_streams
    incremental_streams = ows.incremental_ingestion_streams

    # Sanity checks
    # Params should not be empty strings.
    # Columns should be list of unique elements.
    # for stream in full_streams:
    #   assert stream.name
    #  assert stream.source
    # assert stream.columns and len(stream.columns) == len(set(stream.columns))
    for stream in full_streams:
        assert stream.name
        assert stream.source
        assert stream.columns and len(stream.columns) == len(set(stream.columns))

    for stream in incremental_streams:
        assert stream.source
        assert stream.columns and len(stream.columns) == len(set(stream.columns))
        assert stream.ingest_window is not None
        assert stream.ingest_window.method in ow.WINDOW_METHOD_FLAGS
        assert stream.ingest_window.duration_hours >= 0
        assert stream.precombine_field in stream.columns
        assert stream.record_key_field in stream.columns


def test_full_stream():
    from common.streams import FullStream, sql_keyword_escape
    stream = FullStream(
        name='test_name',
        source='test_source',
        columns=['col1', 'col2'],
        column_transforms={'col1': sql_keyword_escape},
    )
    assert stream.query() == '''( SELECT [col1], col2 FROM test_source ) AS test_name'''


def test_incremental_stream():
    from common.streams import IncrementalStream, sql_keyword_escape
    from common.stream import CLOSED_METHOD, OPEN_END_METHOD, IngestWindow

    # query shall be closed query
    stream_closed_window = IncrementalStream(
        name='test_name',
        source='test_source',
        columns=['col1', 'col2'],
        column_transforms={'col1': sql_keyword_escape},
        record_key_field='test_rkf',
        precombine_field='test_pcf',
        ingest_window=IngestWindow(168, CLOSED_METHOD)
    )
    print(stream_closed_window.query())
    # Test query for the CLOSED window method
    assert stream_closed_window.query() == (
        '''(SELECT [col1], col2 FROM test_source WHERE '''
        '''CONVERT(datetime, DATEADD(second, test_pcf, '19700101')) > '''
        '''CONVERT(datetime, DATEADD(hour, -168, '{{ ds_nodash }}')) AND '''
        '''CONVERT(datetime, DATEADD(second, test_pcf, '19700101')) <= '''
        '''CONVERT(datetime, '{{ ds_nodash }}')) AS test_name'''
    )
    # Test query for the OPEN_END window method
    stream_open_end_window = IncrementalStream(
        name='test_name_open_end',
        source='test_source',
        columns=['col1', 'col2'],
        column_transforms={'col1': sql_keyword_escape},
        record_key_field='test_rkf',
        precombine_field='test_pcf',
        ingest_window=IngestWindow(168, OPEN_END_METHOD)
    )
    print("###################")
    print(stream_open_end_window.query())
    assert stream_closed_window.query() == (
        '''(SELECT [col1], col2 FROM test_source WHERE '''
        '''CONVERT(datetime, DATEADD(second, test_pcf, '19700101')) > '''
        '''CONVERT(datetime, DATEADD(hour, -168, '{{ ds_nodash }}')) AND '''
        '''CONVERT(datetime, DATEADD(second, test_pcf, '19700101')) <= '''
        '''CONVERT(datetime, '{{ ds_nodash }}')) AS test_name'''
    )
    # query shall be full query (no ingest window)
    stream_null_window = IncrementalStream(
        name='test_name_full',
        source='test_source',
        columns=['col1', 'col2'],
        column_transforms={'col1': sql_keyword_escape},
        record_key_field='test_rkf',
        precombine_field='test_pcf',
        ingest_window=None
    )
    print("##################")
    assert stream_null_window.query() == '''(SELECT [col1], col2 FROM test_source) AS test_name_full'''


def test_full_query():
    from common.streams import IncrementalStream

    stream = IncrementalStream(
        name='my_stream',
        source='my_table',
        columns=['col1', 'col2', 'col3'],
        column_transforms={},
        record_key_field='id',
        precombine_field='timestamp',
        ingest_window=None,
        columns_to_censor=[],
        field_types=['int', 'string', 'date']
    )

    columns_string = stream.get_columns()
    full_sql = stream.full_query(columns_string)

    expected_sql = "(SELECT col1, col2, col3 FROM my_table) AS my_stream"
    assert full_sql == expected_sql

import json
import os


def test_ad_dag_compile(ad_dag_id, dagbag):
    """Test the compilation of the DAG."""
    assert ad_dag_id.startswith("arcus-sa-ow")
    ow_dag = dagbag.get_dag(dag_id=ad_dag_id)
    assert dagbag.import_errors == {}
    print(ow_dag)
    assert ow_dag is not None


def test_dag_task_order(ad_dag_id, dagbag):
    expected_paths = {}
    with open('test/resource/dag_structure.json', 'r') as f:
        expected_paths = json.load(f)
    print(os.getcwd())
    ow_dag = dagbag.get_dag(dag_id=ad_dag_id)
    roots = ow_dag.roots
    full_structure = {}
    for r in roots:
        full_structure[r.task_id] = get_structure(r)
    assert full_structure == expected_paths


def get_structure(current):
    """Recursively get the structure of the DAG's tasks."""
    if not current.downstream_list:
        return {}
    else:
        return {x.task_id: get_structure(x) for x in current.downstream_list}


def test_jdbc_to_base(
    dagbag,
    ad_dag_id,
    mock_owad_variable,
):
    import common.streams as ow
    import common.stream as ows
    enabled_streams = ows.get_enabled_incremental_streams(ow.incremental_ingestion_streams, mock_owad_variable)

    ad_dag = dagbag.get_dag(dag_id=ad_dag_id)
    # task_dict: Dict[str, Operator]
    tasks = ad_dag.task_dict
    source_paths = set()

    for stream in enabled_streams:
        task_key = [k for k in tasks.keys() if 'source-to-curated' in k and stream.name in k]
        assert len(task_key) == 1
        task = tasks[task_key.pop()]
        conf = json.loads(task.conf['spark.cdl.configurationSource'])
        spark_config = conf.get('sparkConfig', {})
        source_paths.add(spark_config.get('sourcePath'))

        for path in [source_paths]:
            for path_str in path:
                assert 'curated' in path_str
                assert 'access' not in path_str


def test_upsert_to_access(
    dagbag,
    ad_dag_id,
    mock_owad_variable,
):
    import common.streams as ow
    import common.stream as ows
    enabled_streams = ows.get_enabled_incremental_streams(ow.incremental_ingestion_streams, mock_owad_variable)

    ad_dag = dagbag.get_dag(dag_id=ad_dag_id)
    # task_dict: Dict[str, Operator]
    tasks = ad_dag.task_dict
    source_paths = set()
    target_Paths = set()
    for stream in enabled_streams:
        task_key = [k for k in tasks.keys() if 'curated-to-access' in k and stream.name in k]
        assert len(task_key) == 1
        task = tasks[task_key.pop()]
        conf = json.loads(task.conf['spark.cdl.configurationSource'])
        spark_config = conf.get('sparkConfig', {})
        source_paths.add(spark_config.get('sourcePath'))
        target_Paths.add(spark_config.get('targetPath'))

        assert len(set(source_paths | target_Paths)) == len(
            source_paths) + len(target_Paths)

        for path in [source_paths]:
            for path_str in path:
                assert 'curated' in path_str
                assert 'access' not in path_str

        for path in [target_Paths]:
            for path_str in path:
                assert 'curated' not in path_str
                assert 'access' in path_str
